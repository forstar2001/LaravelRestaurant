@include('admin.partials.header')
@include('admin.partials.sidebar')
@yield('content')
@include('admin.partials.footer')