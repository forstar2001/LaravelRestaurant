@include('front.partials.header-front')
@yield('content')
@include('front.partials.footer-front')