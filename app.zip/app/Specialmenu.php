<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Specialmenu extends Model{
  protected $table = 'special_menu';
  protected $guarded = [];
}
